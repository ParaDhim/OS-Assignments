#include <linux/types.h>
#include <linux/sched.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/time.h>

#define __NR_print_info 451


SYSCALL_DEFINE1(print_info, pid_t ,pid)
{
	struct task_struct *task;
	task = pid_task(find_vpid(pid),PIDTYPE_PID);

	printk("%d :pid\n",task->pid);
	printk("%d :user_id\n",task->cred->uid.val);
	printk("%d :pgid\n",task->group_leader->pid);
	printk("%s : command path\n",task->comm);

	return 0;
}

//void cleanup_module(void)
//{
//	printk(KERN_INFO"BYE\n");
//}
